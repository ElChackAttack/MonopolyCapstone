To Install and run the project From Command Line:

Ensure Maven is installed on machine then from the directory containing pom.xml run.
mvn clean install
mvn jfx:run