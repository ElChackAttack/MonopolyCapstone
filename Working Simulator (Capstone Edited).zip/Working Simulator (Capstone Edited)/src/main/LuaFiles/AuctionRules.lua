--
-- Created by IntelliJ IDEA.
-- User: userhp
-- Date: 23/02/2016
-- Time: 11:05
-- To change this template use File | Settings | File Templates.
--
local startingPriceMulitplier = 0.1
local incrementMultiplier = 0.05



function getIncrementMultiplier()
    return incrementMultiplier
end

function getStartingPriceMultiplier()
    return startingPriceMulitplier
end