--
-- Created by IntelliJ IDEA.
-- User: userhp
-- Date: 09/02/2016
-- Time: 21:11
-- To change this template use File | Settings | File Templates.
--
local Salary = 200


--Change an implment as wanted.
function calculateSalary()
    return Salary
end


--This Function is used within the java program. do not change the type returned or the name of the function.

function getSalary()
    return calculateSalary()
end



