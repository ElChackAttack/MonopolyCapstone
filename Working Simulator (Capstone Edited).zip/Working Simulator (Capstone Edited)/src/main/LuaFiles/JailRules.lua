--
-- Created by IntelliJ IDEA.
-- User: userhp
-- Date: 09/02/2016
-- Time: 21:17
-- To change this template use File | Settings | File Templates.
--
local amountOfDoublesToBeSentToJail = 3
local amountOfRollsToGetOutOfJail = 3
local feetToPayToGetOutOfJail = 50
local canEarnRent = true

function amountOfDoublesToBeSentToJailFunc()
    return amountOfDoublesToBeSentToJail
end

function amountOfRollsToGetOutOfJailFunc()
    return amountOfRollsToGetOutOfJail
end

function feetToPayToGetOutOfJailFunc()
    return feetToPayToGetOutOfJail
end

function canEarnRentFunc()
    return canEarnRent
end