--
-- Created by IntelliJ IDEA.
-- User: userhp
-- Date: 23/02/2016
-- Time: 10:56
-- To change this template use File | Settings | File Templates.
--
local priceReductionForSellingHouse = 0.5
local priceReductionForSellingHotel = 0.5

function getPriceReductionForSellingOfHotel()
    return priceReductionForSellingHotel
end

function getPriceReductionForSellingOfHouse()
    return priceReductionForSellingHouse
end

