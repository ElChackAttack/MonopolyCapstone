package Cards;

/**
 * Created by userhp on 26/01/2016.
 */
public enum CardAction {
    AdvanceToLocation,CollectMoneyFromBank,GetOutOfJail,GoToJail,PayBank,CollectFromPlayers,
    PayBankDependingOnHousesAndHotelsOwned,GoBackSpaces,AdvanceToNearestUtility,AdvanceToNearestStation,PayPlayers
}
