package Board;

/**
 * Created by marc on 20/11/2015.
 */
public enum Group {
    Brown,LightBlue,Violet,Orange,Red,Yellow,Green,DarkBlue,Utility,Station,GO,Tax,Jail,GoToJail,Chance,CommunityChest,FreeParking
}
