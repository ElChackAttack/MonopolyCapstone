package Rules;

import Players.Player;

/**
 * Created by userhp on 23/02/2016.
 */
public class MoveRules {


    public static void movePlayer(Player player, int spaces) {

    }
}
