package Rules;

/**
 * Created by userhp on 30/01/2016.
 */
public enum MoveType { DiceRoll, Card, GoToJail
}
